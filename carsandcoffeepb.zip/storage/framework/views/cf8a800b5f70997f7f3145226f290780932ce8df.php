
 
<?php $__env->startSection('content'); ?>
<a type="button"  href="<?php echo e(route('event.create')); ?>" class="btn btn-success">Create Event</a>
<br><br><br>
<?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <br> 

    <div class="row">
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-4 mt-5">
            <div class="card ">
                <div class="bg-image hover-overlay ripple" data-mdb-ripple-color="light">
                  <img src="<?php echo e($event->image_url); ?>" class="img-fluid w-100 " style="height: 150px" />
                  <a href="#!">
                    <div class="mask" style="background-color: rgba(251, 251, 251, 0.15);"></div>
                  </a>
                </div>
                <div class="card-body">
                  <h5 class="card-title"><?php echo e($event->event_name); ?></h5>
                  
                  <form action="<?php echo e(route('event.destroy',$event->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
                </div>
              </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel projects\carsandcoffeepb\resources\views/Event/view.blade.php ENDPATH**/ ?>