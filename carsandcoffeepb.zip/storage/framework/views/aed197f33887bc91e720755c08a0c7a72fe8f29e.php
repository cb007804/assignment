<!DOCTYPE html>

<html>

<head>

    <title>Car and Coffe</title>

</head>

<body>

    <h1><?php echo e($details['title']); ?></h1>

    <p><?php echo e($details['body']); ?></p>

   

    <p>Thank you</p>

</body>

</html><?php /**PATH F:\Laravel projects\carsandcoffeepb\resources\views/emails/mail.blade.php ENDPATH**/ ?>