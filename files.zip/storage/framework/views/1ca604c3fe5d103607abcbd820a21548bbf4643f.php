
 
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-11">
        <h2>Add New Image to Gallary</h2>
    </div>
    <div class="col-lg-1">
        <a class="btn btn-warning" href="<?php echo e(url('gallary')); ?>"> Back</a>
    </div>
</div>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<form action="<?php echo e(route('gallary.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="image_namee">Heading Name:</label>
        <input type="text" class="form-control" id="image_name" placeholder="Heading Name" name="image_name">
    </div>
    <div class="form-group">
        <label for="image">Select Image:</label>
        <input type="file" class="form-control" id="image" placeholder="Item Image" name="image" accept="image/*">
    </div>

    <br />
    <button type="submit" class="btn btn-primary">Submit</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel projects\carsandcoffeepb\resources\views/Gallary/create.blade.php ENDPATH**/ ?>