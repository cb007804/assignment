
 
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-11">
        <h2>Add New Event</h2>
    </div>
    <div class="col-lg-1">
        <a class="btn btn-warning" href="<?php echo e(url('item')); ?>"> Back</a>
    </div>
</div>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<form action="<?php echo e(route('event.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="event_name">Event Name:</label>
        <input type="text" class="form-control" id="event_name" placeholder="Event Name" name="event_name">
    </div>
    <div class="form-group">
        <label for="image">Event Image:</label>
        <input type="file" class="form-control" id="image" placeholder="Item Image" name="image" accept="image/*">
    </div>
    <div class="form-group">
        <label for="description">Description:</label>
        <textarea class="form-control" id="description" name="description" rows="4" placeholder="description"></textarea>
    </div>

    <br />
    <button type="submit" class="btn btn-primary">Submit</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel projects\carsandcoffeepb\resources\views/Event/create.blade.php ENDPATH**/ ?>