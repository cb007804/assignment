export interface  Gallary {
    
    id:string,   
    image_name: string, 
    url: string
    
}