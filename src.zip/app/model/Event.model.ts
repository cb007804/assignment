export interface  Event {
    
    id:string,   
    event_name: string, 
    image_url: string,
    description: string
    
}