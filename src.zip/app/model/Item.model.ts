export interface  Item {
    
    id:string,   
    item_name: string, 
    price: string, 
    note: string, 
    image_url: string
    
}